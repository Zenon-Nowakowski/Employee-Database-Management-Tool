namespace Program1
{
    class consoleTables
    {
        public void genAll(string[] lines)
        {
        foreach(string line in lines)
            {
                Console.WriteLine(line);
            }
        }
    }
}